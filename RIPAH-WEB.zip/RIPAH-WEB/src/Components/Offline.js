import React from 'react'

const Offline = () => {
  return (
    <div style={{height:"100vh", width:"100%", display:"flex" , alignItems:"center" , justifyContent:"center" , fontSize:"28px"}}>
You are currently offline

    </div>
  )
}

export default Offline